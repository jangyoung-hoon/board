package com.mysite.sbb;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
/*
	참고. 
	
	자바에서 람다 표현식
	- 간결한 방식으로 익명함수를 표현하기 위해 사용됩니다. 람다 표현식은 주로 함수형 인터페이스를 구현할때 사용되며,
	  함수형 인터페이스는 오직 하나의 추상메소드만을 가지고 있는 인터페이스를 말합니다.
	
	람다 표현식의  문법
	(매개변수 목록) -> { 실행문 }
	
	- 매개변수 목록 : 매소드의 매개변수 목록처럼, 람다 표현식에서도 입력으로 사용될 변수들을 정의합니다.
				  매개변수 타입은 생략할수잇으며, 매개변수가 하나뿐이라면 () 괄호도 생략가능합니다.
	
	- -> 화살표 : 매개변수 목록과 람다 몸체를 구분하는 역할을 합니다.
	
	- 실행문 : 람다 표현식의 본체로, 실제 작업을 수행하는 코드가 들어갑니다.
			 실행문이 단일문장이라면 {}중괄호를 생략가능합니다.
			 하지만 실행문이 반화문이거나 여러개라면 {}중괄호를 사용해야 합니다.
			 
	람다 표현식 예시
	
		예시1. 매개변수가 없는 람다 표현식 코드
		
			() -> System.out.println("Hello Lambda!");
			
		예시2. 매개변수 하나를 받는 람다 표현식 코드
			
			(int a) -> a*a;
			
				매개변수가 하나일 경우 괄호는 생략가능 합니다.
				a -> a*a; 가능
				a*a를 반환 받으려면 앞에 return을 쓰면 가능
				
		예시3. 매개변수 두개를 받고 본문이 여러 줄인 람다 표현식
			
			(int a, int b) -> {
								int sum = a + b;
								System.out.println(sum);
								return sum;
								}
		예시4. 람다 표현식을 인자로 사용하는 예 코드
		
			List<String> names = Arrays.asList("Steve","John","Kim","Park");
			
			Collections.sort(names,(String s1, String s2) -> s1.compareTo(s2) );
			
			
		이러한 람다 표현식은 코드를 더 간결하게 만들고, 메소드의 매개변수로 전달되거나 변수에 할당되는 등 다양한 상황에서 유용하게 사용합니다.
		함수형 인터페이스를 사용하는 다양한 자바 API에서 람다 표현식은 코드를 훨씬 더 직관적이고 간결하게 만들어줍니다.

*/
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.frameoptions.XFrameOptionsHeaderWriter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

//스프링 시큐리티의 설정을 담당할 SecurityConfig.java 
//이 코드는 웹 애플리케이션에서 모든 HTTP요청을 허용하도록 Spring Security를 설정합니다.
//실제 애플리케이션에서는 특정 경로에 대한 접근을 제한 하거나 사용자 인증을 요구하는 등 더 복잡한 보안 설정이 필요할 수 잇다.

//@Configuration은 이 파일이 스프링의 환경 설정 파일임을 의미하는 애너테이션 기호
//				여기서는 스프링 시큐리티를 설정하기 위해 사용했습니다.
//@EnableWebSecurity 는 모든 요청 URL이 스프링 시큐리티 제어를 받도록 만드는 애너테이션 입니다.
//이 애너테이션을 사용하면 스프링 시큐리티를 활성화하는 역할을 합니다.
//내부적으로 SecurityFilterChain클래스가 동작 하여 모든 요청  URL에 이 클래스가 필터로 적용되어
//URL별로 특별한 설정을 할수 있게 됩니다.
//스프링 시큐리티 의 세부설정은 @Bean 애너테이션을 통해 SecurityFilterChain 빈을 자동생성하여 설정할 수 있다.
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)//SecurityConfig에 적용한 @EnableMethodSecurity 애너테이션의 
											//prePostEnabled = true는 QuestionController와 AnswerController에서 
											//로그인 여부를 판별할 때 사용한 @PreAuthorize 애너테이션을 사용하기 위해 반드시 필요한 설정이다.
public class SecurityConfig {

	/*
	 * 빈이란? 빈(bean)은 스프링에 의해 생성 또는 관리되는 객체를 의미한다. 우리가 지금껏 만들어 왔던 컨트롤러, 서비스, 리포지터리 등도
	 * 모두 빈에 해당한다. 또한 앞선 예처럼 @Bean 애너테이션을 통해 자바 코드 내에서 별도로 빈을 정의하고 등록할 수도 있다.
	 */
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

		// 다음은 인증되지 않은 모든 페이지의 요청을 허락한다는 의미이다.
		// 따라서 로그인하지 않더라도 모든 페이지에 접근할 수 있도록 한다.

		// 메소드의 매개변수 HttpSecurity http로 전달받은 httpSecurity객체는 Spring Security 설정을 위한 다양한
		// 메소드를 제공합니다.
		// http.authorizeHttpRequests((authorizeHttpRequests) ->
		// authorizeHttpRequests.requestMatchers(new
		// AntPathRequestMatcher("/**")).permitAll());

		// HttpSecurity객체의 authorizeHttpRequests()메소드를 호출해서 HTTP요청에 대한 접근 제어 및 보안설정을
		// 구성합니다.
		// 구체적으로 이 코드는 모든 경로("/**")에 대한 요청을 누구나 접근할수 있도록 허용합니다.
		//
		http.authorizeHttpRequests((authorizeHttpRequests) -> authorizeHttpRequests
				.requestMatchers(new AntPathRequestMatcher("/**")).permitAll())
				// 스프링 시큐리티가 CSRF 처리 시 H2 콘솔은 예외로 처리할 수 있도록
				/// h2-console/로 시작하는 모든 URL은 CSRF 검증을 하지 않는다는 설정을 추가했다.
				.csrf((csrf) -> csrf.ignoringRequestMatchers(new AntPathRequestMatcher("/h2-console/**")))
				// URL 요청 시 X-Frame-Options 헤더를 DENY 대신 SAMEORIGIN으로 설정하여 오류가 발생하지 않도록 했다.
				// X-Frame-Options 헤더의 값으로 SAMEORIGIN을 설정하면 프레임에 포함된 웹 페이지가 동일한 사이트에서 제공할 때에만
				// 사용이 허락된다.
				.headers((headers) -> headers.addHeaderWriter(
						new XFrameOptionsHeaderWriter(XFrameOptionsHeaderWriter.XFrameOptionsMode.SAMEORIGIN)))
				// .formLogin 메서드는 스프링 시큐리티의 로그인 설정을 담당하는 부분으로,
				// 설정 내용은 로그인 페이지의 URL은 /user/login이고 로그인 성공 시에 이동할 페이지는 루트 URL(/)임을 의미한다.
				.formLogin((formLogin) -> formLogin.loginPage("/user/login").defaultSuccessUrl("/"))
				//로그아웃 기능을 구현하기 위한 설정을 추가했다. 
				//로그아웃 URL을 /user/logout으로 설정하고 로그아웃이 성공하면 루트(/) 페이지로 이동하도록 했다. 
				//그리고 .invalidateHttpSession(true)를 통해 로그아웃 시 생성된 사용자 세션도 삭제하도록 처리했다.
				.logout((logout) -> logout
		                .logoutRequestMatcher(new AntPathRequestMatcher("/user/logout"))
		                .logoutSuccessUrl("/")
		                .invalidateHttpSession(true))
				;
		/*
		 * http.authorizeHttpRequests( (authorizeHttpRequests) -> ....)
		 * 
		 * 설명 : HttpSercuruty객체의 authorizeHttpRequests메소드는 접근 규칙을 정의하기 위한 시작점입니다. 이 메소드는
		 * 람다 표현식을 인자로 받아서 AbstractRequestMatcherRegistry객체를 반환합니다
		 * AbstractRequestMatcherRegistry 객체를 사용하여 특정 HTTP요청에 대한 접근 규칙을 세밀하게 설정할 수 있습니다.
		 * 
		 * authorizeHttpRequests.requestMatchers(new
		 * AntPathRequestMatcher("/**")).permitAll());
		 * 
		 * 설명 : 이부분에서 실제로 접근 규칙을 정의 합니다. requestMatchers(....) 메소드는 특정 요청 패턴을 지정하기 위해
		 * 사용됩니다. 여기서는 new AntPathRequestMatcher("/**")를 사용하여 모든 경로에 대한 요청을 매칭합니다. "**"
		 * 패턴은 모든 경로를 의미합니다.
		 * 
		 * permitAll()
		 * 
		 * 설명 : permitAll()메소드는 매칭된 요청에 대해 모든 사용자의 접근을 허용합니다. 즉,인증된 사용자이든 그렇지 않은 사용자이든
		 * 상관없이 모든 요청이 허용됩니다.
		 * 
		 * Spring Security를 사용하여 어플리케이션의 모든 경로("/**")에 대해 누구나 접근할수 있도록 설정합니다. 이는 일반적으로
		 * 공개적으로 접근 가능한 웹사이트를 구성할때 사용될 수 있지만, 특정 경로에 대한 보안 요구사항이 있을때는 추가적인 접근제어 설정이
		 * 필요합니다.
		 */

		return http.build();
	}

	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	//AuthenticationManager 빈을 생성했다. AuthenticationManager는 스프링 시큐리티의 인증을 처리한다. 
	//AuthenticationManager는 사용자 인증 시 앞에서 작성한 UserSecurityService와
	//PasswordEncoder를 내부적으로 사용하여 인증과 권한 부여 프로세스를 처리한다.
	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration)
			throws Exception {
		return authenticationConfiguration.getAuthenticationManager();
	}
}

/*
 * 스프링 시큐리티를 사용하면 웹 프로그램(애플리케이션)의 보안을 강화하고 사용자 인증 및 권한 부여를 효과적으로 관리할 수 있으며, 외부
 * 공격으로부터 시스템을 보호하는 데 도움을 얻을 수 있다.
 */
