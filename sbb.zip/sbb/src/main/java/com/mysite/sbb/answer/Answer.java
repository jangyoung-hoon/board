package com.mysite.sbb.answer;

import java.time.LocalDateTime;
import java.util.Set;

import com.mysite.sbb.question.Question;
import com.mysite.sbb.user.SiteUser;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Answer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(columnDefinition = "TEXT")
	private String content;

	//답변을 다는 date
	private LocalDateTime createDate;

	@ManyToOne
	private Question question;

	// @ManyToOne 애너테이션을 적용했는데, 이는 사용자 한 명이 답변을 여러 개 작성할 수 있기 때문이다.
	@ManyToOne
	private SiteUser author;

	//수정하는 date
	private LocalDateTime modifyDate;

	//추천기능
	@ManyToMany
	Set<SiteUser> voter;

}
