package com.mysite.sbb.question;

import java.security.Principal;


import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;
import lombok.extern.slf4j.Slf4j;

import com.mysite.sbb.answer.AnswerForm;
import com.mysite.sbb.user.SiteUser;
import com.mysite.sbb.user.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@Slf4j
@RequestMapping("/question")
@RequiredArgsConstructor
@Controller
public class QuestionController {

	private final QuestionService questionService;
	private final UserService userService;

	/*
	 * @GetMapping("/list") public String list(Model model) { List<Question>
	 * questionList = this.questionService.getList();
	 * model.addAttribute("questionList", questionList); return "question_list"; }
	 */
	/*
	 * http://localhost:8080/question/list?page=0와 같이 GET 방식으로 요청된 URL에서 page값을 가져오기
	 * 위해 list 메서드의 매개변수로 @RequestParam(value="page", defaultValue="0") int page가
	 * 추가되었다. URL에 매개변수로 page가 전달되지 않은 경우 기본값은 0이 되도록 설정했다.
	 * 
	 * 스프링 부트(Spring Boot)의 페이징 기능을 구현할 때 첫 페이지 번호는 1이 아닌 0이므로 기본값으로 0을 설정해야 한다. GET
	 * 방식에서는 값을 전달하기 위해서 ?와 & 기호를 사용한다. 첫 번째 파라미터는 ? 기호를 사용하고 그 이후 추가되는 값은 & 기호를
	 * 사용한다.
	 */
	@GetMapping("/list")
	public String list(Model model, @RequestParam(value = "page", defaultValue = "0") int page,
									@RequestParam(value = "kw", defaultValue = "") String kw ) {
		
		 log.info("page:{}, kw:{}", page, kw);
		// page는 Spring Data가 제공하는 인터페이스로, 페이지네이션된 결과 테이터를 표현합니다.
		// paging 객체에는 다음과 같은 속성들이 있는데, 이 속성들은 템플릿에서 페이징을 처리할 때 필요하므로 미리 알아 두자.
		Page<Question> paging = this.questionService.getList(page,kw);
		/*
		 * 속성 설명 paging.isEmpty 페이지 존재 여부를 의미한다(게시물이 있으면 false, 없으면 true).
		 * paging.totalElements 전체 게시물 개수를 의미한다. paging.totalPages 전체 페이지 개수를 의미한다.
		 * paging.size 페이지당 보여 줄 게시물 개수를 의미한다. paging.number 현재 페이지 번호를 의미한다.
		 * paging.hasPrevious 이전 페이지의 존재 여부를 의미한다. paging.hasNext 다음 페이지의 존재 여부를 의미한다.
		 */
		model.addAttribute("paging", paging); //페이지 저장
		model.addAttribute("kw", kw); //검색어 저장(검색어를 입력하고 찾기 버튼을 눌렀을대 검색어 창에 입력한 검색어를 그대로 유지하기 위해서 저장)
		return "question_list";
	}

	@GetMapping(value = "/detail/{id}")
	public String detail(Model model, @PathVariable("id") Integer id, AnswerForm answerForm) {
		Question question = this.questionService.getQuestion(id);
		model.addAttribute("question", question);
		return "question_detail";
	}

	// "[질문 등록하기]" 버튼을 통한 /question/create 요청은 GET 요청에 해당하므로 @GetMapping 애너테이션을
	// 사용했다.
	// questionCreate 메서드는 question_form 템플릿을 출력한다.
	/*
	 * 수정하고 테스트하기 위해 [질문 등록하기] 버튼을 클릭하면 오류가 발생할 것이다. 템플릿의 form 태그에 th:object 속성을
	 * 추가했으므로 QuestionController의 GetMapping으로 매핑한 메서드도 다음과 같이 변경해야 오류가 발생하지 않는다.
	 * 왜냐하면 question_form.html은 [질문 등록하기] 버튼을 통해 GET 방식으로 URL이 요청되더라도 th:object에 의해
	 * QuestionForm 객체가 필요하기 때문이다. 아래의 매개변수 QuestionForm questionForm 가 추가 되어야 합니다.
	 */
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/create")
	public String questionCreate(QuestionForm questionForm) {
		return "question_form";
	}

	// question_form.html에서 질문 제목과 내용을 입력하고 질문내용을 DB의 테이블에 추가 요청이 들어오면 호출되는 메소드
	// POST 방식으로 요청한 /question/create URL을 처리하도록 @PostMapping 애너테이션을 지정한
	// questionCreate 메서드를 추가했다.
	/*
	 * @PostMapping("/create") public String
	 * questionCreate(@RequestParam(value="subject") String
	 * subject, @RequestParam(value="content") String content) {
	 * 
	 * //QuestionService의 create 메서드를 호출하여 질문 데이터(subject, content)를 저장하는 코드를 작성했다.
	 * this.questionService.create(subject, content);
	 * 
	 * return "redirect:/question/list"; // 질문 저장후 질문목록으로 이동 }
	 */

	/*
	 * questionCreate 메서드의 매개변수를 subject, content 대신 QuestionForm 객체로 변경했다. subject,
	 * content 항목을 지닌 폼이 전송되면 QuestionForm의 subject, content 속성이 자동으로 바인딩된다. 이렇게 이름이
	 * 동일하면 함께 연결되어 묶이는 것이 바로 폼의 바인딩 기능이다.
	 * 
	 * 여기서 QuestionForm 매개변수 앞에 @Valid 애너테이션을 적용했다. @Valid 애너테이션을 적용하면
	 * QuestionForm의 @NotEmpty, @Size 등으로 설정한 검증 기능이 동작한다. 그리고 이어지는 BindingResult
	 * 매개변수는 @Valid 애너테이션으로 검증이 수행된 결과를 의미하는 객체이다. BindingResult 매개변수는 항상 @Valid
	 * 매개변수 바로 뒤에 위치해야 한다. 만약 두 매개변수의 위치가 정확하지 않다면 @Valid만 적용되어 입력값 검증 실패 시 400 오류가
	 * 발생한다. 따라서 questionCreate 메서드는 bindResult.hasErrors()를 호출하여 오류가 있는 경우에는 다시 제목과
	 * 내용을 작성하는 화면으로 돌아가도록 했고, 오류가 없을 경우에만 질문이 등록되도록 만들었다.
	 * 
	 * 여기까지 수정했다면 질문 등록 화면에서 아무런 값도 입력하지 말고 [저장하기] 버튼을 클릭해 보자. 아무런 입력값도 입력하지 않았으므로
	 * QuestionForm의 @NotEmpty에 의해 Validation이 실패하여 다시 질문 등록 화면에 머물러 있을 것이다. 하지만
	 * QuestionForm에 설정한 '제목은 필수 항목입니다.'와 같은 오류 메시지는 보이지 않는다. 오류 메시지가 보이지 않는다면 어떤
	 * 항목에서 검증이 실패했는지 알 수가 없다. 어떻게 해야 할까?
	 */
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/create")
	public String questionCreate(@Valid QuestionForm questionForm, BindingResult bindingResult, Principal principal) {
		if (bindingResult.hasErrors()) {
			return "question_form";
		}
		SiteUser siteUser = this.userService.getUser(principal.getName());
		this.questionService.create(questionForm.getSubject(), questionForm.getContent(), siteUser);
		return "redirect:/question/list";
	}
	/*
	 * 로그아웃 상태에서 질문 또는 답변을 등록해 보자. 그럼 다음과 같은 500 오류(서버 오류)가 발생한다. 이는 principal 객체가
	 * 널(null)이라서 발생한 오류이다. principal 객체는 로그인을 해야만 생성되는 객체인데 현재는 로그아웃 상태이므로
	 * principal 객체에 값이 없어 오류가 발생하는 것이다. 이 문제를 해결하려면 principal 객체를 사용하는
	 * 메서드에 @PreAuthorize("isAuthenticated()") 애너테이션을 사용해야 한다.
	 * 
	 * @PreAuthorize("isAuthenticated()") 애너테이션이 붙은 메서드는 로그인한 경우에만 실행된다. 즉, 이 애너테이션을
	 * 메서드에 붙이면 해당 메서드는 로그인한 사용자만 호출할 수 있다.
	 * 
	 * @PreAuthorize("isAuthenticated()") 애너테이션이 적용된 메서드가 로그아웃 상태에서 호출되면 로그인 페이지로 강제
	 * 이동된다. 먼저, QuestionController부터 다음과 같이 수정해 보자.
	 * 
	 */

	/*
	 * 이와 같이 questionModify 메서드를 추가했다. 만약 현재 로그인한 사용자와 질문의 작성자가 동일하지 않을 경우에는 '수정 권한이
	 * 없습니다.'라는 오류가 발생하도록 했다. 그리고 수정할 질문의 제목과 내용을 화면에 보여 주기 위해 questionForm 객체에
	 * id값으로 조회한 질문의 제목(subject)과 내용(object)의 값을 담아서 템플릿으로 전달했다. 이 과정이 없다면 질문 수정 화면에
	 * '제목', '내용'의 값이 채워지지 않아 비워져 보일 것이다. 그런데 여기서 한 가지 짚고 넘어가야 할 것이 있다. 질문을 수정할 수 있는
	 * 새로운 템플릿을 만들지 않고 질문을 등록했을 때 사용한 question_form.html 템플릿을 사용한다는 점이다.
	 */

	// Get방식으로 질문테이블의 수정요청이 들어오면
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/modify/{id}")
	public String questionModify(QuestionForm questionForm, @PathVariable("id") Integer id, Principal principal) {

		Question question = this.questionService.getQuestion(id);

		if (!question.getAuthor().getUsername().equals(principal.getName())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
		}
		questionForm.setSubject(question.getSubject());
		questionForm.setContent(question.getContent());
		return "question_form";
	}

	// Post방식으로 질문테이블 수정요청이 들어오면
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/modify/{id}")
	public String questionModify(@Valid QuestionForm questionForm, BindingResult bindingResult, Principal principal,
			@PathVariable("id") Integer id) {
		if (bindingResult.hasErrors()) {
			return "question_form";
		}
		Question question = this.questionService.getQuestion(id);
		if (!question.getAuthor().getUsername().equals(principal.getName())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
		}
		// 수정한 질문 데이터를 수정하기위해 메소드 호출!
		this.questionService.modify(question, questionForm.getSubject(), questionForm.getContent());
		// 수정이 완료되면 페이지를 재요청(리다이렉트)
		return String.format("redirect:/question/detail/%s", id);
	}

	// 삭제 요청이 들어오면
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/delete/{id}")
	public String questionDelete(Principal principal, @PathVariable("id") Integer id) {
		Question question = this.questionService.getQuestion(id);

		// 작성자의 아이디와 로그인한 아이디를 비교하여 다르면 삭제권한이 없습니다. 띄워주기
		if (!question.getAuthor().getUsername().equals(principal.getName())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제권한이 없습니다.");
		}
		this.questionService.delete(question);
		return "redirect:/"; // 8080 port번호 / mainController타고 메인페이지
	}
	
	//
	@PreAuthorize("isAuthenticated()")//추천 기능도 로그인한 사람만 사용할 수 있도록 @PreAuthorize("isAuthenticated( )") 애너테이션을 적용
	@GetMapping("/vote/{id}")
	public String questionVote(Principal principal, @PathVariable("id") Integer id) {
		Question question = this.questionService.getQuestion(id);
		SiteUser siteUser = this.userService.getUser(principal.getName());
		this.questionService.vote(question, siteUser);//QuestionService의 vote 메서드를 호출하여 사용자(siteUser)를 추천인(voter)으로 저장했다.
		return String.format("redirect:/question/detail/%s", id);//오류가 없다면 추천인을 저장한 후 질문 상세 화면으로 리다이렉트한다.
	}

}
