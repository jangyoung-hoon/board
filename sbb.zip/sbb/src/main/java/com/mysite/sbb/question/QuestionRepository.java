package com.mysite.sbb.question;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/*
	테이블의 데이터를 조회, 저장, 수정, 삭제 하는 기능을 하는 메소드를 제공하는 
	JpaRepository클래스를 상속받아 레파지토리 인터페이스를 만들어 SQL문을 생성 후 실행하게됨

	JpaRepository에서 제공하는 메소드들
		<S extends T> save(S entity)     엔티티(테이블과연결된 클래스) 저장 및 수정 
		void delete(T entity) 			 엔티티 삭제 
		count()							 엔티티의 총 갯수 조회해서 반환 
		Iterable<T> findAll()			 엔티티에 저장된 모든 행을 조회
		
*/
public interface QuestionRepository extends JpaRepository<Question, Integer> {
		   //참고. 아래의 문법중에서 (엔티티이름)은 생략이 가능 하다~
	       
			//find+(엔티티이름)+By+변수이름
		   	//find+         +By+변수이름 
     Question findBySubject(String subject);

      Question findBySubjectAndContent(String subject, String content);
      
      List<Question> findBySubjectLike(String subject);
      
      //Pageble 객체를 입력받아 page<Question> 타입 객체를 리턴하는 findAll 메소드를 생성했다.
      Page<Question> findAll(Pageable pageable);
      
      //검색요청
      Page<Question> findAll(Specification<Question> spec, Pageable pageable);
      
      
      
      //@Query 애너테이션 사용하기
      @Query("select "
              + "distinct q "
              + "from Question q " 
              + "left outer join SiteUser u1 on q.author=u1 "
              + "left outer join Answer a on a.question=q "
              + "left outer join SiteUser u2 on a.author=u2 "
              + "where "
              + "   q.subject like %:kw% "
              + "   or q.content like %:kw% "
              + "   or u1.username like %:kw% "
              + "   or a.content like %:kw% "
              + "   or u2.username like %:kw% ")
      Page<Question> findAllByKeyword(@Param("kw") String kw, Pageable pageable);
      /*
       @Query 애너테이션이 적용된 findAllByKeyword 메서드를 추가했다. 
       앞에서 살펴본 쿼리를 @Query로 구현한 것이다. 이때 @Query는 반드시 테이블 기준이 아닌 엔티티 기준으로 작성해야 한다. 
       즉, site_user와 같은 테이블명 대신 SiteUser처럼 엔티티명을 사용해야 하고, 
       조인문에서 보듯이 q.author_id=u1.id와 같은 컬럼명 대신 q.author=u1처럼 엔티티의 속성명을 사용해야 한다.
	   그리고 @Query에 매개변수로 전달할 kw 문자열은 메서드의 매개변수에 @Param("kw")처럼 @Param 애너테이션을 사용해야 한다. 
	   검색어를 의미하는 kw 문자열은 @Query 안에서 :kw로 참조된다.
       */
      
       
}








