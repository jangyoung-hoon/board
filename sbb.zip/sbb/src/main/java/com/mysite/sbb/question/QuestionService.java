package com.mysite.sbb.question;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.mysite.sbb.DataNotFoundException;
import com.mysite.sbb.answer.Answer;
import com.mysite.sbb.user.SiteUser;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class QuestionService {

	private final QuestionRepository questionRepository;

	/*
	  search 메서드는 검색어를 가리키는 kw를 입력받아 쿼리의 조인문과 where문을 Specification 객체로 생성하여 리턴하는
	  메서드이다. 코드를 자세히 보면 앞서 살펴본 쿼리를 자바 코드로 그대로 재현한 것임을 알 수 있다.
	  
	  q:  Root 자료형으로, 즉 기준이 되는 Question 엔티티의 객체를 의미하며 질문 제목과 내용을 검색하기 위해 필요하다. 
	  u1: Question 엔티티와 SiteUser 엔티티를 아우터 조인(여기서는 JoinType.LEFT로 아우터 조인을 적용한다.)하여 만든
	      SiteUser 엔티티의 객체이다. Question 엔티티와 SiteUser 엔티티는 author 속성으로 연결되어 있어서
	      q.join("author")와 같이 조인해야 한다. u1 객체는 질문 작성자를 검색하기 위해 필요하다. 
	  a:  Question 엔티티와 Answer 엔티티를 아우터 조인하여 만든 Answer 엔티티의 객체이다. Question 엔티티와 Answer 엔티티는
		  answerList 속성으로 연결되어 있어서 q.join("answerList")와 같이 조인해야 한다. a 객체는 답변 내용을 검색할 때
		  필요하다. 
	  u2: 바로 앞에 작성한 a 객체와 다시 한번 SiteUser 엔티티와 아우터 조인하여 만든 SiteUser 엔티티의 객체로
		  답변 작성자를 검색할 때 필요하다. 그리고 검색어(kw)가 포함되어 있는지를 like 키워드로 검색하기 위해 제목, 내용, 질문 작성자,
		  답변 내용, 답변 작성자 각각에 cb.like를 사용하고 최종적으로 cb.or로 OR 검색(여러 조건 중 하나라도 만족하는 경우 해당
		  항목을 반환하는 검색 조건을 말한다.)이 되게 했다.
	  
	  
	  select 
		  distinct q.id, q.author_id, q.content, q.create_date, q.modify_date, q.subject from question q 
		  left outer join site_user u1 on q.author_id=u1.id
		  left outer join answer a on q.id=a.question_id 
		  left outer join site_user u2 on a.author_id=u2.id 
	  where 
	  	  q.subject like '%스프링%' 
	  	  or q.content like '%스프링%'
	  	  or u1.username like '%스프링%' 
	  	  or a.content like '%스프링%' 
	  	  or u2.username like '%스프링%'
	 */

	// 검색 요청이 들어왔을떄 처리하는 메소드
//1 - search메소드를 만들어서 검색하는 방법이 있고 Repository에서 @Query를 이용해서 검색 할수 있다.
/*	private Specification<Question> search(String kw) {

		return new Specification<>() {
			private static final long serialVersionUID = 1L;

			@Override
			public Predicate toPredicate(Root<Question> q, CriteriaQuery<?> query, CriteriaBuilder cb) {
				query.distinct(true); // 중복을 제거
				Join<Question, SiteUser> u1 = q.join("author", JoinType.LEFT);
				Join<Question, Answer> a = q.join("answerList", JoinType.LEFT);
				Join<Answer, SiteUser> u2 = a.join("author", JoinType.LEFT);
				return cb.or(cb.like(q.get("subject"), "%" + kw + "%"), // 제목
						cb.like(q.get("content"), "%" + kw + "%"), // 내용
						cb.like(u1.get("username"), "%" + kw + "%"), // 질문 작성자
						cb.like(a.get("content"), "%" + kw + "%"), // 답변 내용
						cb.like(u2.get("username"), "%" + kw + "%")); // 답변 작성자
			}
		};
	}
*/
	/*
	 * 질문 내용을 모두 받아와서 뿌려주는 역할을 하는 메소드인데 밑에 페이징처리를 위해서 수정 public List<Question>
	 * getList() { return this.questionRepository.findAll(); }
	 */
	// 질문 리스트를 받는데 페이징 처리를 해서 10개씩 받아오는 메소드
	// getList메소드는 정수 타입의 클릭한 페이지번호를 매개변수로 받아 해당 페이지 번호에 보여줄 질문 목록(Question) 10개를
	// 조회해서 Page객체 배열에 담아 반환하는 메소드

	/*
	 * public Page<Question> getList(int page) {
	 * 
	 * //Pageable객체를 리턴받아 얻을떄 사용한 PageRequest.of(page, 10)메소드 호출 구문에서 page는 조회할 페이지
	 * 번호(클릭한 페이지번호)이고 //10은 한 페이지에 보여줄 질문목록에 객수를 의미 //이렇게 하면 질문 데이터 전체를 조회하지 않고 해당
	 * 페이지번호의 데이터 10개만 조회하도록 SQL문이 만들어집니다. Pageable pageable = PageRequest.of(page,
	 * 10);
	 * 
	 * return this.questionRepository.findAll(pageable); }
	 */
	// 0페이지 번호를 눌렀다고 가정해보자 그럼 일딴 page에 0이 넘어오게된다.
	public Page<Question> getList(int page, String kw) {
		// org.springframework.data.domain.Sort클래스 내부에 저장된Order클래스는 정렬조건을 정의하기 위한 클래스이다.
		// desc() 메소드는 내림차순 정렬을 생성하는데 사용됩니다.
		// 코드는 Spriong Date 프레임워크에서 데이터를 쿼리하고 정렬할 때 사용될 수있습니다.
		// 데이터 베이스에서 데이터를 가져올때 createDate속성을 기준으로 내림차순으로 정렬하여
		// 최신데이터가 먼저 반환될수있도록 합니다

		List<Sort.Order> sorts = new ArrayList<>(); // 배열

		sorts.add(Sort.Order.desc("createDate"));

		// 게시물을 역순(최신순)으로 조회하려면 이와 같이 PageRequest.of 메서드의 세번째 매개변수에 Order객체가 저장되어야됩니다.
		Pageable pageable = PageRequest.of(page, 10, Sort.by(sorts));
//1		Specification<Question> spec = search(kw);

		// Pageable pageable = PageRequest.of(page, 한페이지에 보여줄 목록, 정렬조건 넣기);

//1		return this.questionRepository.findAll(spec, pageable);
		return this.questionRepository.findAllByKeyword(kw, pageable);//위에 search 메소드 사용하지 않고 findAllByKeyword매소드 사용
	}

	public Question getQuestion(Integer id) {
		Optional<Question> question = this.questionRepository.findById(id);
		if (question.isPresent()) {
			return question.get();
		} else {
			throw new DataNotFoundException("question not found");
		}
	}

	// 제목(subject)과 내용(content)을 입력받아 이를 질문으로 저장하는 create 메서드를 만들었다
	public void create(String subject, String content, SiteUser user) {
		Question q = new Question();
		q.setSubject(subject);
		q.setContent(content);
		q.setCreateDate(LocalDateTime.now());
		q.setAuthor(user);
		this.questionRepository.save(q);
	}

	// 수정한 질문 제목을 Question 테이블에 UPDATE
	public void modify(Question question, String subject, String content) {
		question.setSubject(subject);
		question.setContent(content);
		question.setModifyDate(LocalDateTime.now());
		this.questionRepository.save(question);
	}

	// 질문 삭제를 위한 메소드
	public void delete(Question question) {
		this.questionRepository.delete(question);
	}

	// 로그인한 사용자를 질문 엔티티에 추천인으로 저장하기 위한 메소드
	public void vote(Question question, SiteUser siteUser) {
		question.getVoter().add(siteUser);
		this.questionRepository.save(question);
	}

}
