package com.mysite.sbb.user;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class SiteUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //username, email 속성에는 @Column(unique = true)로 지정했다. 
    //여기서 unique = true는 유일한 값만 저장할 수 있음을 의미한다. 
    //즉, 값을 중복되게 저장할 수 없음을 말한다. 이렇게 해야 username과 email에 동일한 값이 저장되는 것을 막을 수 있다.
    @Column(unique = true)//고유값,중복허용X
    private String username;

    private String password;

    @Column(unique = true)//고유값,중복허용X 
    private String email;
}
