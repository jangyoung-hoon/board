package com.mysite.sbb.user;

import lombok.Getter;
/*
스프링 시큐리티는 인증뿌만 아니라 권한도 관리한다.
스프링 시큐리티는 사용자 인증 후에 사용자에게 부여할 권한과 관련된 내용이 필요하다
그러므로 우리는 사용자가 로그인한 후, ADMIN  또는 USER와 같은 권한을 부여해야한다.

UserRole은 enum자료형 (열거 자료형)으로 작성했다.

그리고 UserRole의 ADMIN과 USer 상수는 값을 변경할 필요가 없으므로  @setter 없이 @Getter만 사용할수 있도록 한다
*/


@Getter
public enum UserRole {
	//관리자를 의미하는 ADMIN과 사용자를 의미하는 USER라는 상수를 만들엇따,
	//그리고 ADMIN은  "ROLE_ADMIN" User는 "ROLE_USER" 값을 부여했다
	 ADMIN("ROLE_ADMIN"),
	    USER("ROLE_USER");

	    UserRole(String value) {
	        this.value = value;
	    }

	    private String value;

}
