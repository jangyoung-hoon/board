package com.mysite.sbb.user;

import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.mysite.sbb.DataNotFoundException;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class UserService {

	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;

	// UserRepository를 사용하여 회원(User) 데이터를 생성하는 create메소드 추가
	public SiteUser create(String username, String email, String password) {
		SiteUser user = new SiteUser();
		user.setUsername(username);
		user.setEmail(email);

		// 스프링 시큐리티의 BCryptPasswordEncoder 클래스를 사용하여 암호화하여 비밀번호를 저장했다.
		// BCryptPasswordEncoder 클래스는 비크립트(BCrypt) 해시 함수를 사용하는데,
		// 비크립트는 해시 함수의 하나로 주로 비밀번호와 같은 보안 정보를 안전하게 저장하고 검증할 때 사용하는 암호화 기술이다.
		// BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		// SecurityConfig.java설정파일에서 빈을 생성 의존주입해서 생략
		user.setPassword(passwordEncoder.encode(password));
		this.userRepository.save(user);
		return user;
	}

	public SiteUser getUser(String username) {
		//getUser 메서드는 userRepository의 findByUsername 메서드를 사용하여 쉽게 만들 수 있다.
		//사용자명에 해당하는 데이터가 없을 경우에는 DataNoFoundException이 발생하도록 했다.
		Optional<SiteUser> siteUser = this.userRepository.findByusername(username);
		
		
		if (siteUser.isPresent()) {
			return siteUser.get();
		} else {
			throw new DataNotFoundException("siteuser not found");
		}
	}

}
