package com.mysite.sbb;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mysite.sbb.answer.Answer;
import com.mysite.sbb.answer.AnswerRepository;
import com.mysite.sbb.question.Question;
import com.mysite.sbb.question.QuestionRepository;
import com.mysite.sbb.question.QuestionService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
class SbbApplicationTests {

    @Autowired
    private QuestionRepository questionRepository;//질문테이블 정보 
    											  //조회,추가,수정,삭제 용도 메소드
    
    @Autowired
    private AnswerRepository answerRepository;//답변테이블 정보
    										  //조회, 추가, 수정, 삭제 용도 메소드

    
    
    
    @Autowired
    private QuestionService questionService;
	/*
	 * @Test void testJpa() { for (int i = 1; i <= 300; i++) { String subject =
	 * String.format("테스트 데이터입니다:[%03d]", i); String content = "내용무";
	 * this.questionService.create(subject, content); } }
	 */
    
    
    
    
    
    
    
    
    
    
    /*
    @Test
    void testJpa() {        
        Question q1 = new Question();
        q1.setSubject("sbb가 무엇인가요?");
        q1.setContent("sbb에 대해서 알고 싶습니다.");
        q1.setCreateDate(LocalDateTime.now());
        this.questionRepository.save(q1);  // 첫번째 질문 저장

        Question q2 = new Question();
        q2.setSubject("스프링부트 모델 질문입니다.");
        q2.setContent("id는 자동으로 생성되나요?");
        q2.setCreateDate(LocalDateTime.now());
        this.questionRepository.save(q2);  // 두번째 질문 저장
    }
    */
    /*
    @Test
    void testJpa() {
        List<Question> all = this.questionRepository.findAll();
        assertEquals(2, all.size());

        Question q = all.get(0);
        assertEquals("sbb가 무엇인가요?", q.getSubject());
    }
    */
   /* 
    @Test
    void testJpa() {
        Optional<Question> oq = this.questionRepository.findById(1);
        if(oq.isPresent()) {
            Question q = oq.get();
            assertEquals("sbb가 무엇인가요?", q.getSubject());
        }
    }
    */
    /*
    @Test
    void testJpa() {
        Question q = this.questionRepository.findBySubject("sbb가 무엇인가요?");
        assertEquals(1, q.getId());
    }
    */
    /*
    @Test
    void testJpa() {
        Question q = this.questionRepository.findBySubjectAndContent("sbb가 무엇인가요?", "sbb에 대해서 알고 싶습니다.");
        assertEquals(1, q.getId());
    }
    */
    /*
    @Test
    void testJpa() {
        List<Question> qList = this.questionRepository.findBySubjectLike("sbb%");
        Question q = qList.get(0);
        assertEquals("sbb가 무엇인가요?", q.getSubject());
    }
    */
    /*
    @Test
    void testJpa() {
        Optional<Question> oq = this.questionRepository.findById(2);
        assertTrue(oq.isPresent());
        Question q = oq.get();
        q.setSubject("수정된 제목");
        this.questionRepository.save(q);
    }
    */
    /*
    @Test
    void testJpa() {
        //Question테이블(엔티티)에 전체 행의 갯수 조회
    	//조회된 행의 갯수가 2줄이면 테스트 통과 
    	assertEquals(5, this.questionRepository.count());
        												//질문 id열의 값이 1인 행을 조회 
        Optional<Question> oq = this.questionRepository.findById(2);
        assertTrue(oq.isPresent());//행이 조회되면?
        Question q = oq.get(); //행을 얻어 
        this.questionRepository.delete(q);//삭제 
        assertEquals(4, this.questionRepository.count());//다시 전체 행의 갯수 조회 
        												 //조회된 행의 갯수가 4줄이면 테스트 통과
    }
    */
    /*
    @Test
    void testJpa() {
    	
        Optional<Question> oq = this.questionRepository.findById(3);//질문id가 2인 행 조회 
        assertTrue(oq.isPresent());//조회가 되면?
        Question q = oq.get();//조회된 행의 정보 얻는다.

        //답변 테이블에 답변 정보를 추가하기 위한 insert문장을 만들어서 save메소드로 실행한다.
        Answer a = new Answer();
        a.setContent("네 자동으로 생성됩니다.");
        a.setQuestion(q);  // 어떤 질문의 답변인지 알기위해서 Question 객체가 필요하다.
        a.setCreateDate(LocalDateTime.now()); //답변 글 추가 일시 정보 추가 
        this.answerRepository.save(a);
    }
    */
    /*
    @Test
    void testJpa() {
        Optional<Answer> oa = this.answerRepository.findById(3);
        assertTrue(oa.isPresent());
        Answer a = oa.get();
        assertEquals(3, a.getQuestion().getId());
    }
    */
    /*
    @Transactional
    @Test
    void testJpa() {
        Optional<Question> oq = this.questionRepository.findById(3);
        assertTrue(oq.isPresent());
        Question q = oq.get();

        List<Answer> answerList = q.getAnswerList();

        assertEquals(1, answerList.size());
//        assertEquals("sbb에 대해서 알고 싶습니다.", answerList.get(0).getContent());
    }
    */
    
    
        
}
























